﻿using System;
using System.Windows.Forms;


namespace Bleu
{
	// Token: 0x02000004 RID: 4
	public partial class Explorer : Form
	{
		// Token: 0x0600000B RID: 11 RVA: 0x00002CFA File Offset: 0x00000EFA
		public Explorer()
		{
			this.InitializeComponent();
		}

		private void Explorer_Load(object sender, EventArgs e)
		{

		}
	}
}
