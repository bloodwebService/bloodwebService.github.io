﻿namespace Bleu
{
	// Token: 0x02000004 RID: 4
	public partial class Explorer : global::System.Windows.Forms.Form
	{
		// Token: 0x0600000C RID: 12 RVA: 0x00002D08 File Offset: 0x00000F08
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600000D RID: 13 RVA: 0x00002D28 File Offset: 0x00000F28
		private void InitializeComponent()
		{
			this.SuspendLayout();
			// 
			// Explorer
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 461);
			this.Name = "Explorer";
			this.Text = "Explorer";
			this.Load += new System.EventHandler(this.Explorer_Load);
			this.ResumeLayout(false);

		}

		// Token: 0x0400000B RID: 11
		private global::System.ComponentModel.IContainer components;
	}
}
