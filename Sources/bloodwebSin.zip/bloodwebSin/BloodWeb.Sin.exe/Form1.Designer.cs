﻿namespace BloodWeb.Sin.exe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
			this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
			this.bunifuDragControl3 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
			this.bunifuFormFadeTransition1 = new Bunifu.Framework.UI.BunifuFormFadeTransition(this.components);
			this.fastColoredTextBox1 = new FastColoredTextBoxNS.FastColoredTextBox();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.bloodwebToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.hookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.autoHookerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.onToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.offToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.topMostToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.oNToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.oOFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.killRBLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.executerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.autoExecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.OpenFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.SaveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
			this.Injecter = new System.Windows.Forms.Timer(this.components);
			this.bunifuThinButton24 = new Bunifu.Framework.UI.BunifuThinButton2();
			this.bunifuThinButton23 = new Bunifu.Framework.UI.BunifuThinButton2();
			this.bunifuThinButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
			((System.ComponentModel.ISupportInitialize)(this.fastColoredTextBox1)).BeginInit();
			this.menuStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
			this.SuspendLayout();
			// 
			// bunifuDragControl1
			// 
			this.bunifuDragControl1.Fixed = true;
			this.bunifuDragControl1.Horizontal = true;
			this.bunifuDragControl1.TargetControl = null;
			this.bunifuDragControl1.Vertical = true;
			// 
			// bunifuDragControl2
			// 
			this.bunifuDragControl2.Fixed = true;
			this.bunifuDragControl2.Horizontal = true;
			this.bunifuDragControl2.TargetControl = null;
			this.bunifuDragControl2.Vertical = true;
			// 
			// bunifuDragControl3
			// 
			this.bunifuDragControl3.Fixed = true;
			this.bunifuDragControl3.Horizontal = true;
			this.bunifuDragControl3.TargetControl = null;
			this.bunifuDragControl3.Vertical = true;
			// 
			// bunifuFormFadeTransition1
			// 
			this.bunifuFormFadeTransition1.Delay = 1;
			// 
			// fastColoredTextBox1
			// 
			this.fastColoredTextBox1.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
			this.fastColoredTextBox1.AutoScrollMinSize = new System.Drawing.Size(179, 14);
			this.fastColoredTextBox1.BackBrush = null;
			this.fastColoredTextBox1.CharHeight = 14;
			this.fastColoredTextBox1.CharWidth = 8;
			this.fastColoredTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.fastColoredTextBox1.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
			this.fastColoredTextBox1.Font = new System.Drawing.Font("Courier New", 9.75F);
			this.fastColoredTextBox1.ForeColor = System.Drawing.Color.Red;
			this.fastColoredTextBox1.IsReplaceMode = false;
			this.fastColoredTextBox1.Location = new System.Drawing.Point(12, 47);
			this.fastColoredTextBox1.Name = "fastColoredTextBox1";
			this.fastColoredTextBox1.Paddings = new System.Windows.Forms.Padding(0);
			this.fastColoredTextBox1.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
			this.fastColoredTextBox1.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("fastColoredTextBox1.ServiceColors")));
			this.fastColoredTextBox1.Size = new System.Drawing.Size(611, 277);
			this.fastColoredTextBox1.TabIndex = 11;
			this.fastColoredTextBox1.Text = "fastColoredTextBox1";
			this.fastColoredTextBox1.Zoom = 100;
			this.fastColoredTextBox1.Load += new System.EventHandler(this.fastColoredTextBox1_Load);
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.bloodwebToolStripMenuItem,
            this.executerToolStripMenuItem,
            this.editToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(635, 24);
			this.menuStrip1.TabIndex = 15;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 20);
			// 
			// bloodwebToolStripMenuItem
			// 
			this.bloodwebToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hookToolStripMenuItem,
            this.autoHookerToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.topMostToolStripMenuItem,
            this.killRBLToolStripMenuItem});
			this.bloodwebToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.bloodwebToolStripMenuItem.Image = global::BloodWeb.Sin.exe.Properties.Resources.Havoxc;
			this.bloodwebToolStripMenuItem.Name = "bloodwebToolStripMenuItem";
			this.bloodwebToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
			this.bloodwebToolStripMenuItem.Text = "Bloodweb";
			// 
			// hookToolStripMenuItem
			// 
			this.hookToolStripMenuItem.Name = "hookToolStripMenuItem";
			this.hookToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.hookToolStripMenuItem.Text = "Hook";
			this.hookToolStripMenuItem.Click += new System.EventHandler(this.hookToolStripMenuItem_Click);
			// 
			// autoHookerToolStripMenuItem
			// 
			this.autoHookerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.onToolStripMenuItem,
            this.offToolStripMenuItem});
			this.autoHookerToolStripMenuItem.Name = "autoHookerToolStripMenuItem";
			this.autoHookerToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.autoHookerToolStripMenuItem.Text = "Auto hooker";
			this.autoHookerToolStripMenuItem.Click += new System.EventHandler(this.autoHookerToolStripMenuItem_Click);
			// 
			// onToolStripMenuItem
			// 
			this.onToolStripMenuItem.Name = "onToolStripMenuItem";
			this.onToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.onToolStripMenuItem.Text = "On";
			this.onToolStripMenuItem.Click += new System.EventHandler(this.onToolStripMenuItem_Click);
			// 
			// offToolStripMenuItem
			// 
			this.offToolStripMenuItem.Name = "offToolStripMenuItem";
			this.offToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.offToolStripMenuItem.Text = "Off";
			this.offToolStripMenuItem.Click += new System.EventHandler(this.offToolStripMenuItem_Click);
			// 
			// openToolStripMenuItem
			// 
			this.openToolStripMenuItem.Name = "openToolStripMenuItem";
			this.openToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.openToolStripMenuItem.Text = "Open As";
			this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
			// 
			// saveToolStripMenuItem
			// 
			this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
			this.saveToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.saveToolStripMenuItem.Text = "Save";
			this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
			// 
			// saveAsToolStripMenuItem
			// 
			this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
			this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.saveAsToolStripMenuItem.Text = "Save as";
			this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
			// 
			// topMostToolStripMenuItem
			// 
			this.topMostToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oNToolStripMenuItem1,
            this.oOFToolStripMenuItem});
			this.topMostToolStripMenuItem.Name = "topMostToolStripMenuItem";
			this.topMostToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.topMostToolStripMenuItem.Text = "Top-Most";
			// 
			// oNToolStripMenuItem1
			// 
			this.oNToolStripMenuItem1.Name = "oNToolStripMenuItem1";
			this.oNToolStripMenuItem1.Size = new System.Drawing.Size(98, 22);
			this.oNToolStripMenuItem1.Text = "ON";
			this.oNToolStripMenuItem1.Click += new System.EventHandler(this.oNToolStripMenuItem1_Click);
			// 
			// oOFToolStripMenuItem
			// 
			this.oOFToolStripMenuItem.Name = "oOFToolStripMenuItem";
			this.oOFToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
			this.oOFToolStripMenuItem.Text = "OOF";
			this.oOFToolStripMenuItem.Click += new System.EventHandler(this.oOFToolStripMenuItem_Click);
			// 
			// killRBLToolStripMenuItem
			// 
			this.killRBLToolStripMenuItem.Name = "killRBLToolStripMenuItem";
			this.killRBLToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.killRBLToolStripMenuItem.Text = "Kill RBL";
			this.killRBLToolStripMenuItem.Click += new System.EventHandler(this.killRBLToolStripMenuItem_Click);
			// 
			// executerToolStripMenuItem
			// 
			this.executerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.autoExecToolStripMenuItem});
			this.executerToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
			this.executerToolStripMenuItem.Image = global::BloodWeb.Sin.exe.Properties.Resources._7computer_2_512;
			this.executerToolStripMenuItem.Name = "executerToolStripMenuItem";
			this.executerToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
			this.executerToolStripMenuItem.Text = " Executer";
			// 
			// autoExecToolStripMenuItem
			// 
			this.autoExecToolStripMenuItem.Name = "autoExecToolStripMenuItem";
			this.autoExecToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.autoExecToolStripMenuItem.Text = "Auto Exec";
			this.autoExecToolStripMenuItem.Click += new System.EventHandler(this.autoExecToolStripMenuItem_Click);
			// 
			// editToolStripMenuItem
			// 
			this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.redoToolStripMenuItem,
            this.undoToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.selectAllToolStripMenuItem});
			this.editToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
			this.editToolStripMenuItem.Name = "editToolStripMenuItem";
			this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
			this.editToolStripMenuItem.Text = "Edit";
			// 
			// redoToolStripMenuItem
			// 
			this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
			this.redoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.redoToolStripMenuItem.Text = "Redo";
			this.redoToolStripMenuItem.Click += new System.EventHandler(this.redoToolStripMenuItem_Click);
			// 
			// undoToolStripMenuItem
			// 
			this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
			this.undoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.undoToolStripMenuItem.Text = "Undo";
			this.undoToolStripMenuItem.Click += new System.EventHandler(this.undoToolStripMenuItem_Click);
			// 
			// pasteToolStripMenuItem
			// 
			this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
			this.pasteToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.pasteToolStripMenuItem.Text = "Paste";
			this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
			// 
			// copyToolStripMenuItem
			// 
			this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
			this.copyToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.copyToolStripMenuItem.Text = "Copy";
			this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
			// 
			// selectAllToolStripMenuItem
			// 
			this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
			this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.selectAllToolStripMenuItem.Text = "Select All";
			this.selectAllToolStripMenuItem.Click += new System.EventHandler(this.selectAllToolStripMenuItem_Click);
			// 
			// sToolStripMenuItem
			// 
			this.sToolStripMenuItem.Name = "sToolStripMenuItem";
			this.sToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			this.sToolStripMenuItem.Text = "S";
			// 
			// OpenFileDialog1
			// 
			this.OpenFileDialog1.FileName = "openFileDialog1";
			// 
			// SaveFileDialog1
			// 
			this.SaveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
			// 
			// fileSystemWatcher1
			// 
			this.fileSystemWatcher1.EnableRaisingEvents = true;
			this.fileSystemWatcher1.SynchronizingObject = this;
			// 
			// bunifuThinButton24
			// 
			this.bunifuThinButton24.ActiveBorderThickness = 1;
			this.bunifuThinButton24.ActiveCornerRadius = 20;
			this.bunifuThinButton24.ActiveFillColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton24.ActiveForecolor = System.Drawing.Color.White;
			this.bunifuThinButton24.ActiveLineColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton24.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.bunifuThinButton24.BackgroundImage = global::BloodWeb.Sin.exe.Properties.Resources.Havoxc;
			this.bunifuThinButton24.ButtonText = "EXECUTE";
			this.bunifuThinButton24.Cursor = System.Windows.Forms.Cursors.Hand;
			this.bunifuThinButton24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bunifuThinButton24.ForeColor = System.Drawing.Color.Black;
			this.bunifuThinButton24.IdleBorderThickness = 1;
			this.bunifuThinButton24.IdleCornerRadius = 20;
			this.bunifuThinButton24.IdleFillColor = System.Drawing.Color.Black;
			this.bunifuThinButton24.IdleForecolor = System.Drawing.Color.Red;
			this.bunifuThinButton24.IdleLineColor = System.Drawing.Color.Red;
			this.bunifuThinButton24.Location = new System.Drawing.Point(12, 332);
			this.bunifuThinButton24.Margin = new System.Windows.Forms.Padding(5);
			this.bunifuThinButton24.Name = "bunifuThinButton24";
			this.bunifuThinButton24.Size = new System.Drawing.Size(114, 39);
			this.bunifuThinButton24.TabIndex = 10;
			this.bunifuThinButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.bunifuThinButton24.Click += new System.EventHandler(this.bunifuThinButton24_Click);
			// 
			// bunifuThinButton23
			// 
			this.bunifuThinButton23.ActiveBorderThickness = 1;
			this.bunifuThinButton23.ActiveCornerRadius = 20;
			this.bunifuThinButton23.ActiveFillColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton23.ActiveForecolor = System.Drawing.Color.White;
			this.bunifuThinButton23.ActiveLineColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton23.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.bunifuThinButton23.BackgroundImage = global::BloodWeb.Sin.exe.Properties.Resources.Havoxc;
			this.bunifuThinButton23.ButtonText = "CLEAR";
			this.bunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand;
			this.bunifuThinButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bunifuThinButton23.ForeColor = System.Drawing.Color.Black;
			this.bunifuThinButton23.IdleBorderThickness = 1;
			this.bunifuThinButton23.IdleCornerRadius = 20;
			this.bunifuThinButton23.IdleFillColor = System.Drawing.Color.Black;
			this.bunifuThinButton23.IdleForecolor = System.Drawing.Color.Red;
			this.bunifuThinButton23.IdleLineColor = System.Drawing.Color.Red;
			this.bunifuThinButton23.Location = new System.Drawing.Point(136, 332);
			this.bunifuThinButton23.Margin = new System.Windows.Forms.Padding(5);
			this.bunifuThinButton23.Name = "bunifuThinButton23";
			this.bunifuThinButton23.Size = new System.Drawing.Size(114, 39);
			this.bunifuThinButton23.TabIndex = 9;
			this.bunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.bunifuThinButton23.Click += new System.EventHandler(this.bunifuThinButton23_Click);
			// 
			// bunifuThinButton22
			// 
			this.bunifuThinButton22.ActiveBorderThickness = 1;
			this.bunifuThinButton22.ActiveCornerRadius = 20;
			this.bunifuThinButton22.ActiveFillColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton22.ActiveForecolor = System.Drawing.Color.White;
			this.bunifuThinButton22.ActiveLineColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton22.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.bunifuThinButton22.BackgroundImage = global::BloodWeb.Sin.exe.Properties.Resources.Havoxc;
			this.bunifuThinButton22.ButtonText = "OPEN";
			this.bunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand;
			this.bunifuThinButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bunifuThinButton22.ForeColor = System.Drawing.Color.Black;
			this.bunifuThinButton22.IdleBorderThickness = 1;
			this.bunifuThinButton22.IdleCornerRadius = 20;
			this.bunifuThinButton22.IdleFillColor = System.Drawing.Color.Black;
			this.bunifuThinButton22.IdleForecolor = System.Drawing.Color.Red;
			this.bunifuThinButton22.IdleLineColor = System.Drawing.Color.Red;
			this.bunifuThinButton22.Location = new System.Drawing.Point(260, 332);
			this.bunifuThinButton22.Margin = new System.Windows.Forms.Padding(5);
			this.bunifuThinButton22.Name = "bunifuThinButton22";
			this.bunifuThinButton22.Size = new System.Drawing.Size(114, 39);
			this.bunifuThinButton22.TabIndex = 8;
			this.bunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.bunifuThinButton22.Click += new System.EventHandler(this.bunifuThinButton22_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.BackgroundImage = global::BloodWeb.Sin.exe.Properties.Resources.Havoxc;
			this.ClientSize = new System.Drawing.Size(635, 378);
			this.Controls.Add(this.fastColoredTextBox1);
			this.Controls.Add(this.bunifuThinButton24);
			this.Controls.Add(this.bunifuThinButton23);
			this.Controls.Add(this.bunifuThinButton22);
			this.Controls.Add(this.menuStrip1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.menuStrip1;
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "Form1";
			this.Text = "BloodWeb.Sin";
			this.TransparencyKey = System.Drawing.Color.DarkRed;
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.fastColoredTextBox1)).EndInit();
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl3;
        private Bunifu.Framework.UI.BunifuFormFadeTransition bunifuFormFadeTransition1;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton23;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton24;
        private FastColoredTextBoxNS.FastColoredTextBox fastColoredTextBox1;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem sToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem bloodwebToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem hookToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem autoHookerToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem executerToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem autoExecToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
		private System.Windows.Forms.OpenFileDialog OpenFileDialog1;
		private System.Windows.Forms.SaveFileDialog SaveFileDialog1;
		private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
		private System.IO.FileSystemWatcher fileSystemWatcher1;
		private System.Windows.Forms.ToolStripMenuItem onToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem offToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem topMostToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem oNToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem oOFToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem killRBLToolStripMenuItem;
		private System.Windows.Forms.Timer Injecter;
		private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton22;
	}
}

