﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bleu;
using IceMemeUI;
using ScintillaNET;
using WeAreDevs_API;

namespace BloodWeb.Sin.exe
{
	public partial class Form1 : Form

	{
		ExploitAPI api = new ExploitAPI();
		private bool InjectOk = true;
		private bool AutoHook = true;
		private object scintilla1;

		[DllImport("kernel32.dll")]
		public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr GetModuleHandle(string lpModuleName);

		[DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
		private static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

		[DllImport("kernel32.dll")]
		private static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);

		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		private static extern int SendMessage(IntPtr hWnd, int msg, int wParam, [MarshalAs(UnmanagedType.LPWStr)] string lParam);


		public string FileLocation { get; private set; }
		public object INPUT_EXECUTE { get; private set; }
		public object ScriptString { get; private set; }
		public object OutputCheck { get; private set; }

		
		public Form1()
		{
			
			InitializeComponent();

		}

		private void Form1_Load(object sender, EventArgs e)
		{
			InjectOk = true;
		    AutoHook = true;
	}

		private void fastColoredTextBox1_Load(object sender, EventArgs e)
		{
			fastColoredTextBox1.Language = FastColoredTextBoxNS.Language.Lua;
			fastColoredTextBox1.Text = "-- By The BloodWeb Team";
		}

		private void bunifuThinButton23_Click(object sender, EventArgs e)
		{
			fastColoredTextBox1.Text = "";
		}

		private void button1_Click(object sender, EventArgs e)
		{


		}

		private void bunifuThinButton21_Click(object sender, EventArgs e)
		{

		}

		private void bunifuThinButton25_Click(object sender, EventArgs e)
		{

		}

		private void bunifuThinButton22_Click(object sender, EventArgs e)
		{
			Stream myStream;

			OpenFileDialog openFileDialog1 = new OpenFileDialog();
			openFileDialog1.Title = "Open Files";
			openFileDialog1.Filter = "TextFiles|*.txt|LuaFile|*.lua| AllFiles|*.*";
			if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				if ((myStream = openFileDialog1.OpenFile()) != null)
				{
					string strfilename = openFileDialog1.FileName;
					string filetext = File.ReadAllText(strfilename);
					fastColoredTextBox1.Text = filetext;
				}
			}
		}

		private void bunifuCheckbox1_OnChange(object sender, EventArgs e)
		{

		}

		private void trackBar1_Scroll(object sender, EventArgs e)
		{

		}

		private void flatMini1_Click(object sender, EventArgs e)
		{
			fastColoredTextBox1.Redo();
		}

		private void bloodwebsinToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}

		private void redoToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}

		private void undoToolStripMenuItem_Click(object sender, EventArgs e)
		{
			fastColoredTextBox1.Undo();
		}

		private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
		{
			fastColoredTextBox1.Paste();
		}

		private void copyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			fastColoredTextBox1.Copy();
		}

		private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
		{
			fastColoredTextBox1.SelectAll();
		}

		private void openToolStripMenuItem_Click(object sender, EventArgs e)
		{

			if (this.FileLocation == "")
			{
				if (this.OpenFileDialog1.ShowDialog() == DialogResult.Cancel)
					return;
				try
				{
					this.FileLocation = this.OpenFileDialog1.FileName;
					this.fastColoredTextBox1.Text = System.IO.File.ReadAllText(this.OpenFileDialog1.FileName);
				}
				catch
				{
				}
			}
			else
			{
				switch (MessageBox.Show("Do you want to save your changes?", "Confirmation", MessageBoxButtons.YesNoCancel))
				{
					case DialogResult.Yes:
						try
						{
							System.IO.File.WriteAllText(this.FileLocation, this.fastColoredTextBox1.Text);
						}
						catch
						{
						}
						if (this.OpenFileDialog1.ShowDialog() == DialogResult.Cancel)
							break;
						try
						{
							this.FileLocation = this.OpenFileDialog1.FileName;
							this.fastColoredTextBox1.Text = System.IO.File.ReadAllText(this.OpenFileDialog1.FileName);
							break;
						}
						catch
						{
							break;
						}
					case DialogResult.No:
						if (this.OpenFileDialog1.ShowDialog() == DialogResult.Cancel)
							break;
						try
						{
							this.FileLocation = this.OpenFileDialog1.FileName;
							this.fastColoredTextBox1.Text = System.IO.File.ReadAllText(this.OpenFileDialog1.FileName);
							break;
						}
						catch
						{
							break;
						}
				}
			}
		}

		private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
		{

		}

		private void cmdboxToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}

		private void FillMatches(string origstr)
		{


		}

		private void CmdBox_TextChanged(object sender, EventArgs e)
		{


		}

		private string FindPlayer(string str, string name)
		{
			return "local " + name.ToLower() + " = (function() local str = [===[" + str + "]===] if str == 'me' then return game:GetService('Players').LocalPlayer else for i,v in pairs(game:GetService('Players'):GetPlayers()) do  if v.Name:sub(1, str:len()) == str then return v end end end return game:GetService('Players').LocalPlayer end)();";
		}

		private string FindPlayers(string str, string func)
		{
			string str1 = "{";
			string str2 = str;
			char[] chArray = new char[1] { ',' };
			foreach (string str3 in str2.Split(chArray))
				str1 = str1 + "[===[" + str3.ToLower() + "]===],";
			return "local function getPlayers(plrs) local newt = {} for i,v in pairs(plrs) do if v == 'me' then table.insert(newt, game:GetService('Players').LocalPlayer) elseif v == 'all' then for o,b in pairs(game:GetService('Players'):GetPlayers()) do table.insert(newt, b) end elseif v == 'others' then for o,b in pairs(game:GetService('Players'):GetPlayers()) do if b ~= game:GetService('Players').LocalPlayer then table.insert(newt, b) end end else for o,b in pairs(game:GetService('Players'):GetPlayers()) do if b.Name:sub(1, v:len()):lower() == v:lower() then table.insert(newt, b) end end  end end return newt end for i,p in pairs(getPlayers(" + (str1 + "}") + ")) do " + func + " end";
		}

		private void DoCmd(string str)
		{
			this.SendInput(this.INPUT_EXECUTE, 0, "spawn(function()pcall(function() " + str + " end)\nend)");
		}

		private void DoCommand(string str)
		{

			if (Uri.IsWellFormedUriString(str, UriKind.Absolute))
				this.SendInput(this.INPUT_EXECUTE, 0, "spawn(function() loadstring(game:HttpGet([===[" + str + "]===], true))() \nend)");
			else
				this.SendInput(this.INPUT_EXECUTE, 0, "spawn(function() " + str + "\nend)");

		}

		private void SendInput(object iNPUT_EXECUTE, int v1, string v2)
		{
			throw new NotImplementedException();
		}



		private void CmdBox_KeyPress(object sender, KeyPressEventArgs e)
		{
		}

		private void CmdBox_Leave(object sender, EventArgs e)
		{

		}

		private void cmdToolStripMenuItem1_Click(object sender, EventArgs e)
		{

		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{

		}

		private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
		{

		}

		public void SendInput(int Mode, int Type, string Data)
		{
			try
			{
				System.IO.File.WriteAllText("INPUT", Mode.ToString() + Type.ToString() + Data);
			}
			catch
			{
			}
		}
		public void ReceiveOutput(int Mode, int Type, string Data)
		{


		}
		private int Inject(string dllName)
		{
			try
			{
				Process process = Process.GetProcessesByName("RobloxPlayerBeta")[0];
				if (process != null)
				{
					if (process.MainWindowHandle.ToInt32() != 0)
					{
						IntPtr hProcess = Form1.OpenProcess(1082, false, process.Id);
						IntPtr procAddress = Form1.GetProcAddress(Form1.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
						IntPtr num = Form1.VirtualAllocEx(hProcess, IntPtr.Zero, (uint)((dllName.Length + 1) * Marshal.SizeOf(typeof(char))), 12288U, 4U);
						UIntPtr lpNumberOfBytesWritten;
						Form1.WriteProcessMemory(hProcess, num, Encoding.Default.GetBytes(dllName), (uint)((dllName.Length + 1) * Marshal.SizeOf(typeof(char))), out lpNumberOfBytesWritten);
						Form1.CreateRemoteThread(hProcess, IntPtr.Zero, 0U, procAddress, num, 0U, IntPtr.Zero);
						this.Text = "BloodWeb.Sin [Hooked]";
					}
				}
				else
					System.IO.File.Create("00");
				return 0;
			}
			catch (Exception ex)
			{
				this.Text = "BloodWeb.Sin";
				return 0;
			}
		}



		private void autoHookerToolStripMenuItem_Click(object sender, EventArgs e)
		{


		}

		private void onToolStripMenuItem_Click(object sender, EventArgs e)
		{
			
		}

		private void offToolStripMenuItem_Click(object sender, EventArgs e)
		{
			
		}

		private void openAsToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}
		private async void Injector_Tick(object sender, EventArgs e)
		{
			if (!this.InjectOk)
				return;
			try
			{
				this.Inject("exploit-main.dll");
			}
			catch
			{
			}
		}
		public bool Filter1(string s)
		{
			return !(s == "") && !(s == ".txt") && (!(s == ".lua") && s.ToLower().LastIndexOf("(1)") == -1) && (s.ToLower().LastIndexOf("(2)") == -1 && s.ToLower().LastIndexOf("(3)") == -1 && (s.ToLower().LastIndexOf("(4)") == -1 && s.ToLower().LastIndexOf("(5)") == -1));
		}

		private string Filter2(string s)
		{
			return s;
		}

		private void fastColoredTextBox2_Load(object sender, EventArgs e)
		{

		}

		private void textBox1_TextChanged_1(object sender, EventArgs e)
		{


		}



		private void scriptBox_TextChanged(object sender, EventArgs e)
		{

		}

		private void scintilla1_Click(object sender, EventArgs e)
		{

		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void oNToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			this.TopMost = true;
		}

		private void oOFToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.TopMost = false;
		}

		private void killRBLToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				foreach (Process process in Process.GetProcessesByName("RobloxPlayerBeta"))
					process.Kill();
			}
			catch
			{
			}
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.FileLocation == "")
			{
				if (this.SaveFileDialog1.ShowDialog() == DialogResult.Cancel)
					return;
				try
				{
					this.FileLocation = this.SaveFileDialog1.FileName;
					System.IO.File.Create(this.SaveFileDialog1.FileName).Close();
					System.IO.File.WriteAllText(this.SaveFileDialog1.FileName, this.fastColoredTextBox1.Text);
				}
				catch
				{
				}
			}
			else
			{
				try
				{
					System.IO.File.WriteAllText(this.FileLocation, this.fastColoredTextBox1.Text);
				}
				catch
				{
				}
			}
		}

		private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.SaveFileDialog1.ShowDialog() == DialogResult.Cancel)
				return;
			try
			{
				this.FileLocation = this.SaveFileDialog1.FileName;
				System.IO.File.Create(this.SaveFileDialog1.FileName).Close();
				System.IO.File.WriteAllText(this.SaveFileDialog1.FileName, this.fastColoredTextBox1.Text);
			}
			catch
			{
			}
		}

		private void hookToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Functions.Inject();
		}

		private void bunifuThinButton24_Click(object sender, EventArgs e)
		{
			string box = fastColoredTextBox1.Text;
			api.SendLimitedLuaScript(box);
		}

		private void autoExecToolStripMenuItem_Click(object sender, EventArgs e)
		{
			
		}
	}
}