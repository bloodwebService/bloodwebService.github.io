﻿// Decompiled with JetBrains decompiler
// Type: Bleu.Indexes
// Assembly: Bleu, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E7AECF97-AD48-485A-9F03-0CC2F4405308
// Assembly location: C:\Users\PvPSt\Downloads\Bleu.exe

using System;
using System.Collections.Generic;

namespace Bleu
{
  public static class Indexes
  {
    public static List<int> AllIndexesOf(this string str, string value)
    {
      if (string.IsNullOrEmpty(value))
        throw new ArgumentException("the string to find may not be empty", nameof (value));
      List<int> intList = new List<int>();
      int startIndex = 0;
      while (true)
      {
        int num = str.IndexOf(value, startIndex);
        if (num != -1)
        {
          intList.Add(num);
          startIndex = num + value.Length;
        }
        else
          break;
      }
      return intList;
    }
  }
}
