﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BloodWeb.Sin.exe
{
	public partial class Updater : Form
	{
		public Updater()
		{
			InitializeComponent();
		}

		private void Updater_Load(object sender, EventArgs e)
		{
			
			if (System.IO.File.Exists("./exploit-main.dll"))
				System.IO.File.Delete("./exploit-main.dll");
			WebClient webClient = new WebClient();
			webClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(this.Client_DownloadProgressChanged);
			webClient.DownloadFileCompleted += new AsyncCompletedEventHandler(this.Client_DownloadFileCompleted);
			webClient.DownloadFileAsync(new Uri("https://cdn.wearedevs.net/software/exploitapi/exploit-main.dll"), "./exploit-main.dll");
		}
		

		private void Client_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
		{
			label1.Text = "exploit-main.dll found!";
			Form1 FM= new Form1();

			// Show the settings form
			FM.Show();

			this.Hide();
		}

		private void Client_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
		{
			this.progressBar1.Maximum = (int)e.TotalBytesToReceive / 100;
			this.progressBar1.Value = (int)e.BytesReceived / 100;
		}

		private void label2_Click(object sender, EventArgs e)
		{
			
		}
	}
}
