﻿namespace Name_your_windowFormapp_any_thing_that_you_like
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.RTbox = new System.Windows.Forms.RichTextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.formToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.injectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.scriptsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.adminScriptsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gameScriptsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.feRadminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.feInfadminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.rSHGUIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.wLS3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip2 = new System.Windows.Forms.MenuStrip();
			this.cmdsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.fireToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.topMostToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.trueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.fasleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.trueToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.falseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1.SuspendLayout();
			this.menuStrip2.SuspendLayout();
			this.SuspendLayout();
			// 
			// RTbox
			// 
			this.RTbox.Location = new System.Drawing.Point(12, 27);
			this.RTbox.Name = "RTbox";
			this.RTbox.Size = new System.Drawing.Size(400, 204);
			this.RTbox.TabIndex = 0;
			this.RTbox.Text = "";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(12, 250);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(122, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "Run Script";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(290, 250);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(122, 23);
			this.button2.TabIndex = 2;
			this.button2.Text = "Clean";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formToolStripMenuItem,
            this.scriptsToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(424, 24);
			this.menuStrip1.TabIndex = 3;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// formToolStripMenuItem
			// 
			this.formToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.injectToolStripMenuItem});
			this.formToolStripMenuItem.Name = "formToolStripMenuItem";
			this.formToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
			this.formToolStripMenuItem.Text = "Form";
			// 
			// injectToolStripMenuItem
			// 
			this.injectToolStripMenuItem.Name = "injectToolStripMenuItem";
			this.injectToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.injectToolStripMenuItem.Text = "Inject";
			this.injectToolStripMenuItem.Click += new System.EventHandler(this.injectToolStripMenuItem_Click);
			// 
			// scriptsToolStripMenuItem
			// 
			this.scriptsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminScriptsToolStripMenuItem,
            this.gameScriptsToolStripMenuItem});
			this.scriptsToolStripMenuItem.Name = "scriptsToolStripMenuItem";
			this.scriptsToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
			this.scriptsToolStripMenuItem.Text = "Scripts";
			// 
			// adminScriptsToolStripMenuItem
			// 
			this.adminScriptsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.feRadminToolStripMenuItem,
            this.feInfadminToolStripMenuItem});
			this.adminScriptsToolStripMenuItem.Name = "adminScriptsToolStripMenuItem";
			this.adminScriptsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.adminScriptsToolStripMenuItem.Text = "Admin scripts";
			// 
			// gameScriptsToolStripMenuItem
			// 
			this.gameScriptsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rSHGUIToolStripMenuItem,
            this.wLS3ToolStripMenuItem});
			this.gameScriptsToolStripMenuItem.Name = "gameScriptsToolStripMenuItem";
			this.gameScriptsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.gameScriptsToolStripMenuItem.Text = "Game Scripts";
			// 
			// feRadminToolStripMenuItem
			// 
			this.feRadminToolStripMenuItem.Name = "feRadminToolStripMenuItem";
			this.feRadminToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.feRadminToolStripMenuItem.Text = "FeRadmin";
			this.feRadminToolStripMenuItem.Click += new System.EventHandler(this.feRadminToolStripMenuItem_Click);
			// 
			// feInfadminToolStripMenuItem
			// 
			this.feInfadminToolStripMenuItem.Name = "feInfadminToolStripMenuItem";
			this.feInfadminToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.feInfadminToolStripMenuItem.Text = "FeInfadmin";
			this.feInfadminToolStripMenuItem.Click += new System.EventHandler(this.feInfadminToolStripMenuItem_Click);
			// 
			// rSHGUIToolStripMenuItem
			// 
			this.rSHGUIToolStripMenuItem.Name = "rSHGUIToolStripMenuItem";
			this.rSHGUIToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.rSHGUIToolStripMenuItem.Text = "RSHGUI";
			this.rSHGUIToolStripMenuItem.Click += new System.EventHandler(this.rSHGUIToolStripMenuItem_Click);
			// 
			// wLS3ToolStripMenuItem
			// 
			this.wLS3ToolStripMenuItem.Name = "wLS3ToolStripMenuItem";
			this.wLS3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.wLS3ToolStripMenuItem.Text = "WLS3";
			this.wLS3ToolStripMenuItem.Click += new System.EventHandler(this.wLS3ToolStripMenuItem_Click);
			// 
			// menuStrip2
			// 
			this.menuStrip2.Dock = System.Windows.Forms.DockStyle.None;
			this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmdsToolStripMenuItem});
			this.menuStrip2.Location = new System.Drawing.Point(146, 249);
			this.menuStrip2.Name = "menuStrip2";
			this.menuStrip2.Size = new System.Drawing.Size(191, 24);
			this.menuStrip2.TabIndex = 4;
			this.menuStrip2.Text = "menuStrip2";
			// 
			// cmdsToolStripMenuItem
			// 
			this.cmdsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fireToolStripMenuItem,
            this.topMostToolStripMenuItem});
			this.cmdsToolStripMenuItem.Name = "cmdsToolStripMenuItem";
			this.cmdsToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
			this.cmdsToolStripMenuItem.Text = "DropList";
			// 
			// fireToolStripMenuItem
			// 
			this.fireToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trueToolStripMenuItem1,
            this.falseToolStripMenuItem});
			this.fireToolStripMenuItem.Name = "fireToolStripMenuItem";
			this.fireToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.fireToolStripMenuItem.Text = "Fire";
			this.fireToolStripMenuItem.Click += new System.EventHandler(this.fireToolStripMenuItem_Click);
			// 
			// topMostToolStripMenuItem
			// 
			this.topMostToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trueToolStripMenuItem,
            this.fasleToolStripMenuItem});
			this.topMostToolStripMenuItem.Name = "topMostToolStripMenuItem";
			this.topMostToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.topMostToolStripMenuItem.Text = "TopMost";
			// 
			// trueToolStripMenuItem
			// 
			this.trueToolStripMenuItem.Name = "trueToolStripMenuItem";
			this.trueToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.trueToolStripMenuItem.Text = "True";
			this.trueToolStripMenuItem.Click += new System.EventHandler(this.trueToolStripMenuItem_Click);
			// 
			// fasleToolStripMenuItem
			// 
			this.fasleToolStripMenuItem.Name = "fasleToolStripMenuItem";
			this.fasleToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.fasleToolStripMenuItem.Text = "Fasle";
			this.fasleToolStripMenuItem.Click += new System.EventHandler(this.fasleToolStripMenuItem_Click);
			// 
			// trueToolStripMenuItem1
			// 
			this.trueToolStripMenuItem1.Name = "trueToolStripMenuItem1";
			this.trueToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
			this.trueToolStripMenuItem1.Text = "True";
			this.trueToolStripMenuItem1.Click += new System.EventHandler(this.trueToolStripMenuItem1_Click);
			// 
			// falseToolStripMenuItem
			// 
			this.falseToolStripMenuItem.Name = "falseToolStripMenuItem";
			this.falseToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.falseToolStripMenuItem.Text = "False";
			this.falseToolStripMenuItem.Click += new System.EventHandler(this.falseToolStripMenuItem_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(424, 285);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.RTbox);
			this.Controls.Add(this.menuStrip1);
			this.Controls.Add(this.menuStrip2);
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "Form1";
			this.Text = "exploit name?";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.menuStrip2.ResumeLayout(false);
			this.menuStrip2.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.RichTextBox RTbox;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem formToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem injectToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem scriptsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem adminScriptsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem feRadminToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem feInfadminToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gameScriptsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem rSHGUIToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem wLS3ToolStripMenuItem;
		private System.Windows.Forms.MenuStrip menuStrip2;
		private System.Windows.Forms.ToolStripMenuItem cmdsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem fireToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem trueToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem falseToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem topMostToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem trueToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem fasleToolStripMenuItem;
	}
}

