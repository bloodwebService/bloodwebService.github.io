﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bloodweb_API; //calls the api from refernces 

namespace Name_your_windowFormapp_any_thing_that_you_like
{
	public partial class Form1 : Form
	{
		ExploitAPI api = new ExploitAPI(); //calls the api from refernces and makes a new string
		public Form1()
		{
			InitializeComponent();
		}

		private void injectToolStripMenuItem_Click(object sender, EventArgs e)
		{
			api.LaunchExploit(); //injects the dll into RobloxPlayerBeta
		}

		private void feRadminToolStripMenuItem_Click(object sender, EventArgs e)
		{
			api.FeRAdmin(); //pre-buit in script
		}

		private void feInfadminToolStripMenuItem_Click(object sender, EventArgs e)
		{
			api.FeInfAdmin(); //pre-buit in script
		}

		private void rSHGUIToolStripMenuItem_Click(object sender, EventArgs e)
		{
			api.ROBLOXHIGHSCHOOLGUI();  //pre-buit game script
		}

		private void wLS3ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			api.WLS3();  //pre-buit game script
		}

		private void button1_Click(object sender, EventArgs e)
		{
			string box = RTbox.Text; // makes a string for the Textbox or whatever you using to put the script in to run
			api.SendLuaScript(box); //calls the namedpipe and runs the script 
		}

		private void button2_Click(object sender, EventArgs e)
		{
			
			RTbox.Text = "";
		}

		private void fireToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}

		private void trueToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			api.AddFire();
		}

		private void falseToolStripMenuItem_Click(object sender, EventArgs e)
		{
			api.RemoveFire();
		}

		private void trueToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.TopMost = true;
		}

		private void fasleToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.TopMost = false;
		}
	}
}
